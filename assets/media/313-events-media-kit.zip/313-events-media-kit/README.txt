313.events media kit
Media contact: jody@sentientproductions.com
313-events-wordmark-on-dark: for dark backgrounds. 313-events-wordmark-on-light: for light backgrounds. SVG preferred; PNGs have transparent backgrounds. Use logos as supplied.
313-events-signal-mark: the standalone signal mark.
313-events-press-kit.pdf: the press kit. 313-events-bios.txt and 313-events-fact-sheet.txt: copy-ready text.
313-events-calendar-mobile-375.png and 313-events-calendar-desktop.png: public product screenshots of the calendar, as of Nov 9, 2026; illustrative UI, counts are not a marketing claim or an audience claim.
